export function generateLoginNode(userJid: any, config: any): proto.ClientPayload;
export function generateRegistrationNode({ registrationId, signedPreKey, signedIdentityKey }: {
    registrationId: any;
    signedPreKey: any;
    signedIdentityKey: any;
}, config: any): proto.ClientPayload;
export function configureSuccessfulPairing(stanza: any, { advSecretKey, signedIdentityKey, signalIdentities }: {
    advSecretKey: any;
    signedIdentityKey: any;
    signalIdentities: any;
}): {
    creds: {
        account: proto.ADVSignedDeviceIdentity & proto.ADVSignedDeviceIdentity.$Properties;
        me: {
            id: any;
            name: any;
            lid: any;
        };
        signalIdentities: any[];
        platform: any;
        registered: boolean;
    };
    reply: {
        tag: string;
        attrs: {
            to: string;
            type: string;
            id: any;
        };
        content: {
            tag: string;
            attrs: {};
            content: {
                tag: string;
                attrs: {
                    'key-index': string;
                };
                content: Uint8Array<ArrayBufferLike>;
            }[];
        }[];
    };
};
export function encodeSignedDeviceIdentity(account: any, includeSignatureKey: any): Uint8Array<ArrayBufferLike>;
import { proto } from '../../WAProto/index.js';
